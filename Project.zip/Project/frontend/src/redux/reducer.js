//reducer
const initialState = {
    isLoggedIn: false,
    emailId: null,
  };
  
  const reducer = (state = initialState, action) => {
    switch (action.type) {
      case 'LOGIN_SUCCESS':
        return {
          ...state,
          isLoggedIn: true,
          emailId: action.payload,
        };
      case 'LOGOUT':
        return {
          ...state,
          isLoggedIn: false,
          emailId: null,
        };
      default:
        return state;
    }
  };
  
  export default reducer;
  