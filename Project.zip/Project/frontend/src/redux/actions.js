
//actions.js
export const loginSuccess = (emailId) => ({
    type: 'LOGIN_SUCCESS',
    payload: emailId,
  });
  
  export const logout = () => ({
    type: 'LOGOUT',
  });
  