import { useNavigate } from 'react-router-dom';
import React, { useState } from 'react';
import axios from 'axios';
import "./ForgotPwd.css";

const ForgotPwd = () => {
  const [emailId, setEmailId] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleEmailIdChange = (e) => {
    setEmailId(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    setLoading(true);

    axios
      .put('http://127.0.0.1:8080/userfunction/forgot-password', null, {
        params: { emailId: emailId },
      })
      .then((response) => {
        console.log(response.data);
        setMessage('Password reset email sent successfully. Check your email for further instructions.');
      })
      .catch((error) => {
        console.error(error);
        if (error.response && error.response.status === 400) {
          setMessage('Invalid Email ID. Enter the correct Email ID for password reset.');
        } else if (error.response && error.response.status === 404) {
          setMessage('User not found for the given email ID.');
        } else {
          setMessage('Error while processing the password reset request.');
        }
      })
      .finally(() => {
        setLoading(false);
        // Clear the message after a few seconds
        setTimeout(() => {
          setMessage('');
        }, 5000);
      });
  };

  return (
    <>
      <center>
        <h1>Allsmart Agritech Finance Manager</h1>
        <div className="pwd-container">
          <h2>Forgot Password</h2>
          <form onSubmit={handleSubmit}>
            <div>
              <label htmlFor="email">Email:</label>
              <input
                type="email"
                id="email"
                value={emailId}
                onChange={handleEmailIdChange}
                required
              />
            </div>
            
            
            <p>Enter Your Email ID, Then <br/><br/>
             We Emailed you a New Password for your Account.</p>
            <br />
            <br />
            <div>
              <button type="submit" id="forgot" disabled={loading}>
                {loading ? 'Processing...' : 'Reset Password'}
              </button>
            </div>
            <br />
          </form>
          <div className="pwd-links">
            <button id="forgot" onClick={() => navigate('/login')}>  Go to Login  </button>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <button id="forgot" onClick={() => navigate('/signup')}>Go to Register</button>
          </div>
          <br />
        </div>
        {message && <p className="message">{message}</p>}
      </center>
    </>
  );
};

export default ForgotPwd;

