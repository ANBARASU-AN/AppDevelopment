

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import "./UpdateUserDetails.css";

const UpdateUserDetails = () => {
  const [userDetails, setUserDetails] = useState({
    firstName: '',
    lastName: '',
    gender: '',
    age: '',
    emailId: '', // This will be taken from localStorage
    mobile: '',
    newEmailId: '', // Mandatory new emailId
  });

  const [message, setMessage] = useState('');
  const [reset, setReset] = useState(false);
  const navigate = useNavigate();
  const [showUpdate, setShowUpdate] = useState(false);

  useEffect(() => {
    // Load the existing emailId from localStorage
    const existingEmailId = localStorage.getItem('emailId');

    // Set the initial state with the existing emailId
    setUserDetails((prevUserDetails) => ({
      ...prevUserDetails,
      emailId: existingEmailId || '',
    }));
  }, []);

  useEffect(() => {
    if (reset) {
      const timeoutId = setTimeout(() => {
        setReset(false);
        setMessage('');
      }, 3000);

      // Cleanup the timeout to avoid side effects
      return () => clearTimeout(timeoutId);
    }
  }, [reset]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserDetails((prevUserDetails) => ({
      ...prevUserDetails,
      [name]: value,
    }));
  };

  const handleUpdate = async () => {
    const { emailId, newEmailId, ...updatedDetails } = userDetails;

    // Ensure newEmailId is provided and not empty
    if (!newEmailId.trim()) {
      setMessage('New EmailId is mandatory');
      // Display the error message for 5 seconds
      setTimeout(() => {
        setMessage('');
      }, 5000);
      return;
    }

    

    try {
      await axios.put(`http://localhost:8080/userfunction/updateDetailsByEmail/${emailId}`, {
        ...updatedDetails,
        emailId: newEmailId,
      });

      if (emailId !== newEmailId) {
        setMessage('EmailId are Not Same, So Login Again using your New EmailID ');
        // Display the error message for 5 seconds
        setTimeout(() => {
          setMessage('');
          navigate('/login');
        }, 5000);
        return;
        }

      setReset(true);
      setMessage('User details updated successfully');
    } catch (error) {
      setMessage(error.response?.data || 'Error updating user details');
      // Display the error message for 5 seconds
      setTimeout(() => {
        setMessage('');
      }, 5000);
    }
  };

  return (
    <div>
      <button className='userdetails-button' id='userdetails-button' onClick={() => setShowUpdate(!showUpdate)}>
        Click Here To {showUpdate ? 'Hide' : 'View'} Update User Details Option
      </button>

      {showUpdate && (
        <div className='userdetails-container'>
          <form id='userdetails'>
            <label >
              Your Login Email ID:&nbsp;
              <input id='userdetails-input'  type="text" name="emailId" value={userDetails.emailId} readOnly />
            </label>
            
            <label >
              New Email ID:
              <input  id='userdetails-input'type="text" name="newEmailId" value={userDetails.newEmailId} onChange={handleChange} />
            </label>
            
            <label >
              First Name:
              <input  id='userdetails-input'type="text" name="firstName" value={userDetails.firstName} onChange={handleChange} />
            </label>
            
            <label >
              Last Name:
              <input  id='userdetails-input'type="text" name="lastName" value={userDetails.lastName} onChange={handleChange} />
            </label>
            
            <label>
              Gender:
             
              <select
                value={userDetails.gender}
                id='userdetails-input'type="text" name="gender"
                required
                onChange={handleChange} autoComplete="off" >
                <option value=""></option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
          </select>
            </label>
            
            <label >
              Age:
              <input  id='userdetails-input'type="number" name="age" value={userDetails.age} onChange={handleChange} 
              autoComplete="off" 
              />
            </label>
           
            <label>
              Mobile: 
             
              <input  id='userdetails-input'type="text" name="mobile" value={userDetails.mobile} onChange={handleChange} />
            </label>
            <center>
            
            <button className='userdetails-submit' id='userdetails-submit' type="button" onClick={handleUpdate}>
              Update Details
            </button></center>
          </form>
          {message && <p>{message}</p>}
        </div>
      )}
    </div>
  );
};

export default UpdateUserDetails;






/*

import React, { useState, useEffect } from 'react';

const UpdateUserDetails = () => {
  const [userDetails, setUserDetails] = useState({
    firstName: '',
    lastName: '',
    gender: '',
    age: '',
    emailId: '', // This will be taken from localStorage
    mobile: '',
    newEmailId: '', // Mandatory new emailId
  });

  useEffect(() => {
    // Load the existing emailId from localStorage
    const existingEmailId = localStorage.getItem('emailId');

    // Set the initial state with the existing emailId
    setUserDetails((prevUserDetails) => ({
      ...prevUserDetails,
      emailId: existingEmailId || '',
    }));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserDetails((prevUserDetails) => ({
      ...prevUserDetails,
      [name]: value,
    }));
  };

  const handleUpdate = () => {
    const { emailId, newEmailId, ...updatedDetails } = userDetails;

    // Ensure newEmailId is provided and not empty
    if (!newEmailId.trim()) {
      console.error('New EmailId is mandatory');
      // Handle the case where newEmailId is not provided
      return;
    }

    fetch(`http://localhost:8080/userfunction/updateDetailsByEmail/${emailId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        ...updatedDetails,
        emailId: newEmailId,
      }),
    })
      .then((response) => {
        if (response.ok) {
          return response.json();
        }
        throw new Error('User not found');
      })
      .then((data) => {
        console.log('User details updated successfully:', data);
        // Handle success, e.g., show a success message to the user
      })
      .catch((error) => {
        console.error('Error updating user details:', error.message);
        // Handle error, e.g., show an error message to the user
      });
  };

  return (
    <div>
      <h2>Update User Details</h2>
      <form>
        <label>
          EmailId (from localStorage):
          <input type="text" name="emailId" value={userDetails.emailId} readOnly />
        </label>
        <br />
        <label>
          New EmailId (mandatory):
          <input type="text" name="newEmailId" value={userDetails.newEmailId} onChange={handleChange} />
        </label>
        <br />
        <label>
          First Name:
          <input type="text" name="firstName" value={userDetails.firstName} onChange={handleChange} />
        </label>
        <br />
        <label>
          Last Name:
          <input type="text" name="lastName" value={userDetails.lastName} onChange={handleChange} />
        </label>
        <br />
        <label>
          Gender:
          <input type="text" name="gender" value={userDetails.gender} onChange={handleChange} />
        </label>
        <br />
        <label>
          Age:
          <input type="text" name="age" value={userDetails.age} onChange={handleChange} />
        </label>
        <br />
        <label>
          Mobile:
          <input type="text" name="mobile" value={userDetails.mobile} onChange={handleChange} />
        </label>
        <br />
        <button type="button" onClick={handleUpdate}>
          Update Details
        </button>
      </form>
    </div>
  );
};

export default UpdateUserDetails;




*/