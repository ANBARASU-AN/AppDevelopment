import React, { useEffect, useState } from 'react';
import "./AdminHome.css";

const AdminHome = () => {
  const [userDetails, setUserDetails] = useState([]);

  useEffect(() => {
    // Function to fetch user details
    const fetchUserDetails = async () => {
      try {
        const response = await fetch('http://127.0.0.1:8080/userfunction/admin/getDetails');
        if (response.status === 200) {
          const data = await response.json();
          setUserDetails(data);
        } else if (response.status === 401) {
          // Handle unauthorized access
          console.error('Unauthorized access');
        } else {
          console.error('Failed to fetch user details');
        }
      } catch (error) {
        console.error('Error fetching user details:', error);
      }
    };

    // Call the fetch function
    fetchUserDetails();
  }, []); // Empty dependency array ensures the effect runs only once after the initial render

  return (
    <div id='adminhome'>
      <h1>User Details</h1>
      <table>
        <thead>
          <tr>
            <th>User ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Gender</th>
            <th>Age</th>
            <th>Email ID</th>
            <th>Mobile</th>
          </tr>
        </thead>
        <tbody>
          {userDetails.map(user => (
            <tr key={user.userid}>
              <td>{user.userid}</td>
              <td>{user.firstName}</td>
              <td>{user.lastName}</td>
              <td>{user.gender}</td>
              <td>{user.age}</td>
              <td>{user.emailId}</td>
              <td>{user.mobile}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AdminHome;
