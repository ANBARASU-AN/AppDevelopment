package com.example.springapp.service;

import java.util.List;
import com.example.springapp.entity.UserFunction;

public interface UserFunctionService {

    void userFunction(UserFunction userFunction);

    UserFunction login(String emailId, String password);

    void resetPassword(String emailId, String password);

    List<UserFunction> getDetails();

    void deleteUser(UserFunction userFunction);

    boolean isEmailIdExists(String emailId);
    
    UserFunction findByEmailId(String emailId);
    
    void changePassword(String emailId, String oldPassword, String newPassword);

	UserFunction getUserByEmailId(String emailId);
	
	UserFunction loginUser(String emailId, String password);
	
}


