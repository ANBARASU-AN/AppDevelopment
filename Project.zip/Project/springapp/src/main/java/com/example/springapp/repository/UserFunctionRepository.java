
package com.example.springapp.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.springapp.entity.UserFunction;

@Repository
public interface UserFunctionRepository extends JpaRepository<UserFunction, Integer> {
	
    UserFunction findByEmailIdAndPassword(String emailId, String password);
    UserFunction findByEmailId(String emailId);
    boolean existsByEmailId(String emailId);

}


