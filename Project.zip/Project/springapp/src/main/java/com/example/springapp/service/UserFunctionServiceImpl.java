package com.example.springapp.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springapp.entity.UserFunction;
import com.example.springapp.repository.UserFunctionRepository;

@Service
public class UserFunctionServiceImpl implements UserFunctionService {

    @Autowired
    private UserFunctionRepository userFunctionRepository;

    @Override
    public void userFunction(UserFunction userFunction) {
        userFunctionRepository.save(userFunction);
    }

    @Override
    public void resetPassword(String emailId, String password) {
        UserFunction userFunction = userFunctionRepository.findByEmailId(emailId);
        userFunction.setPassword(password);
        userFunctionRepository.save(userFunction);
    }

    @Override
    public List<UserFunction> getDetails() {
        return userFunctionRepository.findAll();
    }

    @Override
    public void deleteUser(UserFunction userFunction) {
        userFunctionRepository.delete(userFunction);
    }

    @Override
    public UserFunction findByEmailId(String emailId) {
        return userFunctionRepository.findByEmailId(emailId);
    }

    @Override
    public void changePassword(String emailId, String oldPassword, String newPassword) {
        UserFunction userFunction = userFunctionRepository.findByEmailIdAndPassword(emailId, oldPassword);

        if (userFunction != null) {
            userFunction.setPassword(newPassword);
            userFunctionRepository.save(userFunction);
        } else {
            throw new RuntimeException("Invalid email or password");
        }
    }

    @Override
    public UserFunction getUserByEmailId(String emailId) {
        return userFunctionRepository.findByEmailId(emailId);
    }

    public boolean isEmailIdExists(String emailId) {
        return userFunctionRepository.existsByEmailId(emailId);
    }

    @Override
    public UserFunction login(String emailId, String password) {
        // Fetch the user by email
        UserFunction userFunction = userFunctionRepository.findByEmailId(emailId);

        // Check if the user exists and the passwords match (case-sensitive)
        if (userFunction != null && password.equals(userFunction.getPassword())) {
            return userFunction;
        } else {
            return null;
        }
    }

    public UserFunction loginUser(String emailId, String password) {
        // Find the user by email
        UserFunction existingUser = userFunctionRepository.findByEmailId(emailId);
        if (existingUser == null || !existingUser.getPassword().equals(password)) {
            throw new IllegalArgumentException("Invalid email ID or password");
        }

        return existingUser;
    }
}
