package com.example.springapp.service;

import com.example.springapp.entity.Contact;

public interface ContactService {
    String saveDetails(Contact details);
    String sendSimpleMail(Contact details);
    String sendMailWithAttachment(Contact details);
}
