package com.example.springapp.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
//import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.util.StringUtils;

import com.example.springapp.entity.ChangePasswordRequest;
import com.example.springapp.entity.LoginRequest;
import com.example.springapp.entity.UserFunction;
import com.example.springapp.repository.UserFunctionRepository;
import com.example.springapp.service.UserFunctionService;

@CrossOrigin
@RestController
@RequestMapping("/userfunction")
public class UserFunctionController {

    @Autowired
    @Qualifier("userFunctionServiceImpl")
    private UserFunctionService userFunctionService;

    @PostMapping("/new")
    public ResponseEntity<String> userFunction(@RequestBody UserFunction userFunction) {
        if (userFunction == null) {
            return new ResponseEntity<>("Invalid request", HttpStatus.BAD_REQUEST);
        }
        if (userFunction.getPassword() == null) {
            return new ResponseEntity<>("Password cannot be null", HttpStatus.BAD_REQUEST);
        }

        // Check if the email ID already exists
        if (userFunctionService.isEmailIdExists(userFunction.getEmailId())) {
            return new ResponseEntity<>("Email ID already exists", HttpStatus.CONFLICT);
        }

        userFunctionService.userFunction(userFunction);
        return new ResponseEntity<>("User registered successfully", HttpStatus.OK);
    }

    
    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody LoginRequest loginRequest) {
        try {
            userFunctionService.loginUser(loginRequest.getEmailId(), loginRequest.getPassword());
            // Handle successful login, return a token, etc.
            return ResponseEntity.status(HttpStatus.CREATED).body("Login successful");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
        }
    }
    
    
    @PutMapping("/updateDetailsByEmail/{emailId}")
    public ResponseEntity<String> updateUserDetails(@PathVariable String emailId, @RequestBody UserFunction updatedUser) {
        UserFunction existingUser = userFunctionService.findByEmailId(emailId);

        if (existingUser != null) {
            // Update other user details
            existingUser.setFirstName(updatedUser.getFirstName());
            existingUser.setLastName(updatedUser.getLastName());
            existingUser.setGender(updatedUser.getGender());
            existingUser.setAge(updatedUser.getAge());
            existingUser.setEmailId(updatedUser.getEmailId());
            existingUser.setMobile(updatedUser.getMobile());

            // Save the updated user details
            userFunctionService.userFunction(existingUser);

            return new ResponseEntity<>("User details updated successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
        }
    }
 
 

    private String generateNewPassword() {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder newPassword = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 8; i++) {
            int index = random.nextInt(characters.length());
            newPassword.append(characters.charAt(index));
        }
        return newPassword.toString();
    }

    @Autowired
    private JavaMailSender javaMailSender;

    @PutMapping("/forgot-password")
    public ResponseEntity<String> resetPassword(@RequestParam String emailId) {
    	UserFunction userFunction = userFunctionService.findByEmailId(emailId);

        if (userFunction == null) {
            return new ResponseEntity<>("User not found for the given email ID.", HttpStatus.NOT_FOUND);
        }
        String newPassword = generateNewPassword();
        userFunctionService.resetPassword(emailId, newPassword);
        sendNewPasswordEmail(emailId, newPassword);
        return new ResponseEntity<>("Password reset successful. Check your email for the new password.", HttpStatus.OK);
        
        
    }


    private void sendNewPasswordEmail(String emailId, String newPassword) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(emailId);
        message.setSubject(" Password Reset - Your Allsmart Account");
        message.setText("Dear Customer,\r\n"
                + "\r\n"
                + "We hope this email finds you well. Recently, we received a request to reset the password for your Allsmart account.\r\n"
                + "As a result, we have generated a new password for your account to ensure the security of your information.\r\n"
                + "\r\n"
                + "Your New Password is: [ " + newPassword + " ]\r\n"
                + "\r\n"
                + "Please use this new password to log in to your Allsmart account. Once logged in, we recommend changing your password to something more memorable.\r\n"
                + "If you did not initiate this password reset or have any concerns about the security of your account, please contact our support team immediately.\r\n"
                + "\r\n"
                + "Thank you for your attention to this matter.\r\n"
                + "\r\n"
                + "Best regards,\r\n"
                + "\r\n"
                + "Allsmart\r\n"
                + "Customer Support Team\r\n"
                + "allsmart.org@gmail.com");

        try {
            javaMailSender.send(message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    

    
    @PutMapping("/change-password")
    public ResponseEntity<String> changePassword(@RequestBody ChangePasswordRequest request) {
        String emailId = request.getEmailId();
        String oldPassword = request.getOldPassword();
        String newPassword = request.getNewPassword();

        try {
            // Verify the user with the provided email and old password
            UserFunction userFunction = userFunctionService.login(emailId, oldPassword);

            if (userFunction == null) {
                // User login failed (invalid email or password)
                return new ResponseEntity<>("Invalid email or password. Please check your credentials.", HttpStatus.UNAUTHORIZED);
            }

            // Check if old and new passwords are the same
            if (oldPassword.equals(newPassword)) {
                return new ResponseEntity<>("New password must be different from the old password", HttpStatus.BAD_REQUEST);
            }

            // Update the password with the new one
            userFunctionService.changePassword(emailId, oldPassword, newPassword);

            return new ResponseEntity<>("Password changed successfully", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>("Failed to change password. Please try again later.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    

    @Value("${admin.username}")
    private String adminUsername;

    @Value("${admin.password}")
    private String adminPassword;

    @GetMapping("/admin/login")
    public ResponseEntity<String> adminLogin(@RequestParam String username, @RequestParam String password) {
        if (username.equals(adminUsername) && password.equals(adminPassword)) {
            return new ResponseEntity<>("Admin login successful", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Invalid admin credentials", HttpStatus.UNAUTHORIZED);
        }
    }

    // Helper method to check if the request is from an authenticated admin
    private boolean isAdminAuthenticated() {
        // Add any additional checks for admin authentication if needed
        // For simplicity, this method only checks if the admin credentials are set
        return adminUsername != null && adminPassword != null;
    }

    @GetMapping("/admin/getDetails")
    public ResponseEntity<List<UserFunction>> getDetailsForAdmin() {
        if (!isAdminAuthenticated()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
        }
    
        List<UserFunction> userDetails = userFunctionService.getDetails();
        if (userDetails == null || userDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.OK).body(null);
        }
    
        return ResponseEntity.status(HttpStatus.OK).body(userDetails);
    }
    

    /* 

    @GetMapping("/admin")
    public ResponseEntity<String> adminAccess(@RequestParam String username, @RequestParam String password) {
        if (username.equals(adminUsername) && password.equals(adminPassword)) {
            List<UserFunction> userDetails = userFunctionService.getDetails();
            if (userDetails == null || userDetails.isEmpty()) {
                return new ResponseEntity<>("No user details available", HttpStatus.OK);
            }
            StringBuilder responseMessage = new StringBuilder("Admin access granted. User details:\n");
            for (UserFunction user : userDetails) {
                responseMessage.append(user.toString()).append("\n");
            }
            return new ResponseEntity<>(responseMessage.toString(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Invalid credentials", HttpStatus.UNAUTHORIZED);
        }
    }

    */


    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteUser(@RequestParam String emailId, @RequestParam String password) {
        UserFunction userFunction = userFunctionService.login(emailId, password);
        if (userFunction != null) {
            String fullName = userFunction.getFirstName() + " " + userFunction.getLastName();
            userFunctionService.deleteUser(userFunction);
            return new ResponseEntity<>(fullName + " is deleted", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Invalid credentials", HttpStatus.UNAUTHORIZED);
        }
    }
    
    
    
    
    
    @GetMapping("/profile")
    public ResponseEntity<UserFunction> getProfile(@RequestParam String emailId) {
        try {
        	UserFunction userFunction = userFunctionService.getUserByEmailId(emailId);
            if (userFunction != null) {
                return ResponseEntity.status(HttpStatus.OK).body(userFunction);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
    
    

    
    @Autowired
    private UserFunctionRepository userFunctionRepository;

    @Value("${upload.path}")
    private String uploadPath;

    @PostMapping("/{userid}/uploadImage")
    public ResponseEntity<String> uploadImage(@PathVariable Integer userid, @RequestParam MultipartFile file) {
        try {
        	UserFunction userFunction = userFunctionRepository.findById(userid).orElse(null);

            if (userFunction == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found.");
            }

            // Validate the image file if needed (e.g., file size, file type, etc.)
            String fileName = StringUtils.cleanPath(file.getOriginalFilename());

            // Generate a unique file name to avoid overwriting existing files
            String uniqueFileName = userid + "_" + System.currentTimeMillis() + "_" + fileName;

            // Save the file to the server
            Path directoryPath = Paths.get(uploadPath);
            if (!Files.exists(directoryPath)) {
                Files.createDirectories(directoryPath);
            }

            Path filePath = directoryPath.resolve(uniqueFileName);
            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

            // Update the user's profileImagePath with the file path
            userFunction.setProfileImagePath(uniqueFileName);
            userFunctionRepository.save(userFunction);

            return ResponseEntity.ok("Image uploaded successfully!");
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to upload image.");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal server error.");
        }
    }
    

}




