package com.example.springapp.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="usertable")
public class UserFunction {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="userid")
	private Integer userid;

	@Column(name="FirstName", nullable = false)
	private String firstName;

	@Column(name="LastName", nullable = false)
	private String lastName;
	
	@Column(name="Gender", nullable = false)
	private String gender;
	
	@Column(name="Age", nullable = false)
	private String age;

	@Column(name="EmailId", unique = true,  nullable = false)
	private String emailId;

	@Column(name="Password" , nullable = false)
	private String password;

	@Column(name="Mobile", nullable = false)
	private long mobile;

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	
	@Override
	public String toString() {
		return "UserFunction [userid=" + userid + ", firstName=" + firstName + ", lastName=" + lastName + ", gender="
				+ gender + ", age=" + age + ", emailId=" + emailId + ", password=" + password + ", mobile=" + mobile
				+ ", profileImagePath=" + profileImagePath + "]";
	}
	
	@Column(nullable = true)
    private String profileImagePath;

    // Getters and setters...

    public String getProfileImagePath() {
        return profileImagePath;
    }

    public void setProfileImagePath(String profileImagePath) {
        this.profileImagePath = profileImagePath;
    }
	    	
	
}


