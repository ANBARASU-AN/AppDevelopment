// config.jsx
export const BASE_URL = 'http://127.0.0.1:8082';
