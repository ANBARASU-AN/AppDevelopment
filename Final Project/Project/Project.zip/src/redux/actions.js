
// actions.js

export const loginSuccess = (emailId, token) => ({
  type: 'LOGIN_SUCCESS',
  payload: { emailId, token },
});

export const logout = () => ({
  type: 'LOGOUT',
});

/*


//actions.js
export const loginSuccess = (emailId) => ({
    type: 'LOGIN_SUCCESS',
    payload: emailId,
  });
  
  export const logout = () => ({
    type: 'LOGOUT',
  });
  
  /*
  */