package com.example.springapp.controller;

import static com.example.springapp.utils.MyConstant.ADMIN;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.springapp.entity.Contact;
import com.example.springapp.entity.GmailDetails;
import com.example.springapp.entity.Loan;
import com.example.springapp.entity.Review;
import com.example.springapp.entity.Support;
import com.example.springapp.entity.Users;
import com.example.springapp.service.AdminService;
import com.example.springapp.service.ContactService;
import com.example.springapp.service.LoanService;
import com.example.springapp.service.ReviewService;
import com.example.springapp.service.SupportService;
import com.example.springapp.service.UserFunctionService;


@RestController
@CrossOrigin
@RequestMapping(ADMIN)
public class AdminController {


    private final ReviewService reviewService;
    private final AdminService adminService;

    //@Autowired
    public AdminController(ReviewService reviewService, AdminService adminService) {
        this.reviewService = reviewService;
        this.adminService = adminService;
    }

    @GetMapping("/reviews/showReviews")
    public ResponseEntity<List<Review>> fetchDetails() {
        List<Review> products = reviewService.getDetails();
        return ResponseEntity.ok(products);
    }

    @PostMapping("/sendGmail")
    public String sendMail(@RequestBody GmailDetails details) {
        String status = adminService.sendSimpleMail(details);
        return status;
    }

    @PostMapping("/sendMailWithAttachment")
    public String sendMailWithAttachment(@RequestBody GmailDetails details) {
        String status = adminService.sendMailWithAttachment(details);
        return status;
    }


    /* 
    private final ReviewService reviewService;
    private final AdminService adminService;

    //@Autowired // Constructor injection
    public AdminController(ReviewService reviewService, AdminService adminService) {
        this.reviewService = reviewService;
        this.adminService = adminService;
    }
    
    @GetMapping("/reviews/showReviews")
    public ResponseEntity<List<Review>> fetchDetails() {
        List<Review> products = reviewService.getDetails();
        return ResponseEntity.ok(products);
    }

    // Sending a simple Email
    @PostMapping("/sendGmail")
    public String sendMail(@RequestBody GmailDetails details) {
        String status = adminService.sendSimpleMail(details);
        return status;
    }

    // Sending email with attachment
    @PostMapping("/sendMailWithAttachment")
    public String sendMailWithAttachment(GmailDetails details, MultipartFile attachment) {
        details.setAttachment(attachment);
        String status = adminService.sendMailWithAttachment(details);
        return status;
    }


    */


    /* 
    private final ReviewService reviewService;

    @Autowired // Constructor injection
    public AdminController(ReviewService reviewService) {
        this.reviewService = reviewService;
    }
    
    @GetMapping("/reviews/showReviews")
    public ResponseEntity<List<Review>> fetchDetails() {
        List<Review> products = reviewService.getDetails();
        return ResponseEntity.ok(products);
    }

    private final AdminService adminService;

    //@Autowired
    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    
    
    // Sending a simple Email
    @PostMapping("/sendGmail")
    public String sendMail(@RequestBody GmailDetails details) {
        String status = adminService.sendSimpleMail(details);
        return status;
    }

    // Sending email with attachment
    @PostMapping("/sendMailWithAttachment")
    public String sendMailWithAttachment(GmailDetails details, MultipartFile attachment) {
        details.setAttachment(attachment);
        String status = adminService.sendMailWithAttachment(details);
        return status;
    }

    */

    
    
    @Autowired
    private LoanService loanService;

    // Read (All) - GET
    @GetMapping("/loanApplications")
    public ResponseEntity<List<Loan>> getAllLoanApplications() {
        List<Loan> loanApplications = loanService.findAll();
        return new ResponseEntity<>(loanApplications, HttpStatus.OK);
    }
 

    // Update - PUT
    @PutMapping("//loanApplications/{id}")
    public ResponseEntity<Loan> updateLoanApplication(@PathVariable Long id,
                                                      @RequestBody Loan updatedLoanApplication) {
        Loan loanApplication = loanService.findById(id);
        if (loanApplication != null) {
            updatedLoanApplication.setId(id);
            Loan savedLoanApplication = loanService.save(updatedLoanApplication);
            return new ResponseEntity<>(savedLoanApplication, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    @Autowired
    private ContactService contactService;

    @GetMapping("/getAllContacts")
    public List<Contact> getAllContacts() {
        return contactService.getAllContacts();
    }

    @DeleteMapping("/deleteContact/{contactId}")
    public String deleteContact(@PathVariable Long contactId) {
        return contactService.deleteContact(contactId);
    }


    @Autowired
    private SupportService supportService;

    @GetMapping("/support")
    public List<Support> getAllSupport() {
        return supportService.getAllSupport();
    }

    


    @Autowired
    @Qualifier("userFunctionServiceImpl")
    private UserFunctionService userFunctionService;
    

    @Value("${admin.username}")
    private String adminUsername;

    @Value("${admin.password}")
    private String adminPassword;

    @GetMapping("/login")
    public ResponseEntity<String> adminLogin(@RequestParam String username, @RequestParam String password) {
        if (username.equals(adminUsername) && password.equals(adminPassword)) {
            return new ResponseEntity<>("Admin login successful", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Invalid admin credentials", HttpStatus.UNAUTHORIZED);
        }
    }

    // Helper method to check if the request is from an authenticated admin
    private boolean isAdminAuthenticated() {
        // Add any additional checks for admin authentication if needed
        // For simplicity, this method only checks if the admin credentials are set
        return adminUsername != null && adminPassword != null;
    }

    @GetMapping("/getDetails")
    public ResponseEntity<List<Users>> getDetailsForAdmin() {
        if (!isAdminAuthenticated()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
        }
    
        List<Users> userDetails = userFunctionService.getDetails();
        if (userDetails == null || userDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.OK).body(null);
        }
    
        return ResponseEntity.status(HttpStatus.OK).body(userDetails);
    }


}
