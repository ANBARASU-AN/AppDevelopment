package com.example.springapp.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.example.springapp.entity.Admin;
import com.example.springapp.enumerated.Role;
import com.example.springapp.repository.AdminRepository;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class UserCLI implements CommandLineRunner {

    private final AdminRepository adminRepository; // Inject AdminRepository instead of UserRepository
    private final PasswordEncoder passwordEncoder;

    @Value("${admin.username}")
    private String adminUsername;

    @Value("${admin.password}")
    private String adminPassword;

    @Override
    public void run(String... args) throws Exception {
        if (adminRepository.count() > 0) // Use adminRepository here
            return;
        var admin = Admin.builder()
                .adminUsername(adminUsername)
                .adminPassword(passwordEncoder.encode(adminPassword))
                .role(Role.ADMIN) // Set admin role
                .build();
        adminRepository.save(admin); // Use adminRepository to save admin entity
    }
}

