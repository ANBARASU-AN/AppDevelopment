
package com.example.springapp.enumerated;


public enum Role {
    USER, ADMIN;
}