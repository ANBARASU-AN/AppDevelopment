package com.example.springapp.service;

import org.springframework.stereotype.Service;

import com.example.springapp.entity.GmailDetails;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

import java.io.File;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private JavaMailSender javaMailSender;

    @Value("${spring.mail.username}")
    private String sender;

    @Override
    public String sendSimpleMail(GmailDetails details) {
        try {
            MimeMessage message = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setFrom(sender);
            helper.setTo(details.getRecipient());
            helper.setSubject(details.getSubject());
            helper.setText(details.getMsgBody());
            javaMailSender.send(message);
            return "Mail sent successfully.";
        } catch (MessagingException | MailException e) {
            e.printStackTrace();
            return "Failed to send mail.";
        }
    }

    @Override
    public String sendMailWithAttachment(GmailDetails details) {
        try {
            MimeMessage message = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setFrom(sender);
            helper.setTo(details.getRecipient());
            helper.setSubject(details.getSubject());
            helper.setText(details.getMsgBody());

            if (details.getAttachment() != null) {
                File tempFile = File.createTempFile("attachment", details.getAttachment().getOriginalFilename());
                details.getAttachment().transferTo(tempFile);
                helper.addAttachment(tempFile.getName(), tempFile);
            }

            javaMailSender.send(message);
            return "Mail with attachment sent successfully.";
        } catch (MessagingException | IOException | MailException e) {
            e.printStackTrace();
            return "Failed to send mail with attachment.";
        }
    }
}

/*

package com.example.springapp.service;

import org.springframework.stereotype.Service;

import com.example.springapp.entity.GmailDetails;

@Service
public class AdminServiceImpl implements AdminService {


    @Override
    public String sendSimpleMail(GmailDetails details) {
        // Implementation for sending a simple email
        return "Simple email sent successfully";
    }

    @Override
    public String sendMailWithAttachment(GmailDetails details) {
        // Implementation for sending an email with attachment
        return "Email with attachment sent successfully";
    }
}


*/