




import React, { useEffect, useState } from 'react';
import './AdminHome.css';
import AdminNavbar from './AdminNavbar';
import { BASE_URL } from '../Config.jsx';

const AdminHome = () => {
  const [userDetails, setUserDetails] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchCategory, setSearchCategory] = useState('select');
  const [filteredUserDetails, setFilteredUserDetails] = useState([]);

  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        const response = await fetch(`${BASE_URL}/admin/getDetails`);
        if (response.status === 200) {
          const data = await response.json();
          setUserDetails(data);
          setFilteredUserDetails(data); // Initially set filtered details to all details
        } else if (response.status === 401) {
          console.error('Unauthorized access');
        } else {
          console.error('Failed to fetch user details');
        }
      } catch (error) {
        console.error('Error fetching user details:', error);
      }
    };

    fetchUserDetails();
  }, []);

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleCategoryChange = (event) => {
    setSearchCategory(event.target.value);
  };

  const handleSearchClick = () => {
    if (searchCategory !== 'select') {
      filterUserDetails(searchTerm, searchCategory);
    }
  };

  const handleClearClick = () => {
    setSearchTerm('');
    setSearchCategory('select');
    setFilteredUserDetails(userDetails);
  };

  // Filter user details based on search term and category
  const filterUserDetails = (term, category) => {
    const filteredDetails = userDetails.filter(user => {
      const userValue = user[category].toLowerCase();
      return userValue.includes(term.toLowerCase());
    });
    setFilteredUserDetails(filteredDetails);
  };

  return (
    <>
    <AdminNavbar/>
    <div id='adminhome' className='adminhomecontainer'>
      <h1 id='adminhome'>User Details</h1>
      <div id='adminhome1'className="search-container">
        <label htmlFor="searchCategory" id='adminhome'>Search Category: </label>
        <select
          id='adminhome'
          value={searchCategory}
          onChange={handleCategoryChange}
        >
          <option id='adminhome' value="select">Select</option>
          <option id='adminhome' value="firstName">First Name</option>
          <option id='adminhome' value="lastName">Last Name</option>
          <option id='adminhome' value="emailId">Email ID</option>
        </select>
        <label id='adminhome' htmlFor="search">Search: </label>
        <input
          type="text"
          id='adminhome'
          value={searchTerm}
          onChange={handleSearchChange}
        />
        <button id='adminhome' onClick={handleSearchClick}>Search</button>
        <button id='adminhome' onClick={handleClearClick}>Clear</button>
      </div>
      <div className='adminhometablecontainer'>
      <table id='adminhome'>
        <thead id='adminhome'>
          <tr>
            <th>User ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Gender</th>
            <th>Age</th>
            <th>Email ID</th>
            <th>Mobile</th>
          </tr>
        </thead>
        <tbody>
          {filteredUserDetails.map(user => (
            <tr key={user.userid}>
              <td>{user.userid}</td>
              <td>{user.firstName}</td>
              <td>{user.lastName}</td>
              <td>{user.gender}</td>
              <td>{user.age}</td>
              <td>{user.emailId}</td>
              <td>{user.mobile}</td>
            </tr>
          ))}
        </tbody>
      </table>
      </div>

    </div>
    </>
  );
};

export default AdminHome;




/*


import React, { useEffect, useState } from 'react';
import './AdminHome.css';

const AdminHome = () => {
  const [userDetails, setUserDetails] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredUserDetails, setFilteredUserDetails] = useState([]);

  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        const response = await fetch('http://127.0.0.1:8080/userfunction/admin/getDetails');
        if (response.status === 200) {
          const data = await response.json();
          setUserDetails(data);
          setFilteredUserDetails(data); // Initially set filtered details to all details
        } else if (response.status === 401) {
          console.error('Unauthorized access');
        } else {
          console.error('Failed to fetch user details');
        }
      } catch (error) {
        console.error('Error fetching user details:', error);
      }
    };

    fetchUserDetails();
  }, []);

  const handleSearchChange = (event) => {
    const searchTerm = event.target.value;
    setSearchTerm(searchTerm);
    filterUserDetails(searchTerm);
  };

  const handleClearClick = () => {
    setSearchTerm('');
    setFilteredUserDetails(userDetails);
  };

  // Filter user details based on search term
  const filterUserDetails = (term) => {
    const filteredDetails = userDetails.filter(user => {
      // Convert user.userid to a string before using includes
      const userIdString = String(user.userid);

      return (
        userIdString.includes(term) ||
        user.firstName.toLowerCase().includes(term.toLowerCase()) ||
        user.lastName.toLowerCase().includes(term.toLowerCase()) ||
        user.emailId.toLowerCase().includes(term.toLowerCase())
      );
    });
    setFilteredUserDetails(filteredDetails);
  };

  return (
    <div id='adminhome'>
      <h1>User Details</h1>
      <div>
        <label htmlFor="search">Search: </label>
        <input
          type="text"
          id="search"
          value={searchTerm}
          onChange={handleSearchChange}
        />
        <button onClick={handleClearClick}>Clear</button>
      </div>
      <table>
        <thead>
          <tr>
            <th>User ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Gender</th>
            <th>Age</th>
            <th>Email ID</th>
            <th>Mobile</th>
          </tr>
        </thead>
        <tbody>
          {filteredUserDetails.map(user => (
            <tr key={user.userid}>
              <td>{user.userid}</td>
              <td>{user.firstName}</td>
              <td>{user.lastName}</td>
              <td>{user.gender}</td>
              <td>{user.age}</td>
              <td>{user.emailId}</td>
              <td>{user.mobile}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AdminHome;




/*

import React, { useEffect, useState } from 'react';
import "./AdminHome.css";

const AdminHome = () => {
  const [userDetails, setUserDetails] = useState([]);

  useEffect(() => {
    // Function to fetch user details
    const fetchUserDetails = async () => {
      try {
        const response = await fetch('http://127.0.0.1:8080/userfunction/admin/getDetails');
        if (response.status === 200) {
          const data = await response.json();
          setUserDetails(data);
        } else if (response.status === 401) {
          // Handle unauthorized access
          console.error('Unauthorized access');
        } else {
          console.error('Failed to fetch user details');
        }
      } catch (error) {
        console.error('Error fetching user details:', error);
      }
    };

    // Call the fetch function
    fetchUserDetails();
  }, []); // Empty dependency array ensures the effect runs only once after the initial render

  return (
    <div id='adminhome'>
      <h1>User Details</h1>
      <table>
        <thead>
          <tr>
            <th>User ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Gender</th>
            <th>Age</th>
            <th>Email ID</th>
            <th>Mobile</th>
          </tr>
        </thead>
        <tbody>
          {userDetails.map(user => (
            <tr key={user.userid}>
              <td>{user.userid}</td>
              <td>{user.firstName}</td>
              <td>{user.lastName}</td>
              <td>{user.gender}</td>
              <td>{user.age}</td>
              <td>{user.emailId}</td>
              <td>{user.mobile}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AdminHome;


/*

*/