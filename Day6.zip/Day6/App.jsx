
// using redux
import React, { useState } from 'react';
import { Provider } from 'react-redux';
import store from './redux/store';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import "./App.css";
import SignUp from './SignUp.jsx';
import Login from './Login.jsx';
import HomePage from './Pages/HomePage.jsx';
import Profile from './Pages/Profile.jsx';
import ForgotPwd from './Pages/ForgotPwd.jsx';
import UpdateUserDetails from './Pages/UpdateUserDetails.jsx';
import ChangePassword from './Pages/ChangePassword.jsx';
import Review from './Pages/Review.jsx';
import AboutUs from './Pages/AboutUs.jsx';
import Contact from './Pages/Contact.jsx';
import AdminLogin from './Pages/AdminLogin.jsx';
import AdminHome from './Pages/AdminHome.jsx';

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  return (
    <Provider store={store}>
    <>
    <body>
    <Router>
      <Routes>
        <Route path="/signup" element={<SignUp />} />

        <Route
          path="/login"
          element={<Login setIsLoggedIn={setIsLoggedIn} />}
        />

         <Route path="/admin" element={<AdminLogin setIsLoggedIn={setIsLoggedIn}/>} />

         <Route path="/adminhome" element={isLoggedIn ? <AdminHome /> : <Navigate to="/admin" replace />} />

        <Route path="/updatedetails" element={<UpdateUserDetails />} />

        <Route path="/changepassword" element={<ChangePassword />} />

        <Route path="/forgot-pwd" element={<ForgotPwd />} />

        <Route path="/" element={<HomePage /> } />

        <Route path="/aboutus" element={<AboutUs />} />

        <Route path="/contactus" element={isLoggedIn ? <Contact setIsLoggedIn={setIsLoggedIn} /> : <Navigate to="/login" replace />}/>

        <Route path="/review" element={isLoggedIn ? <Review setIsLoggedIn={setIsLoggedIn} /> : <Navigate to="/login" replace />}/>

        <Route path="/profile" element={ isLoggedIn ? <Profile setIsLoggedIn={setIsLoggedIn} /> : <Navigate to="/login" replace />} />

        
      </Routes>
    </Router>
    </body>
    </></Provider>
  );
};


export default App;


/*
<Route path="/" element={isLoggedIn ? <HomePage /> : <Navigate to="/login" replace />} />
*/