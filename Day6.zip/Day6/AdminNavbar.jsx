import React from "react";
import Logo from "./Images/Allsmart.png";
import "./AdminNavbar.css";
import { Link } from "react-router-dom";

const AdminNavbar = () => {


  return (
    <div className="adminnavborder" >
      <nav id="adminnavbar">
        <div id="adminnavbar" className="logo">
          <Link to="/adminhome">
            <img
              src={Logo}
              id="adminnavbarlogo"
              alt="Profile"
              style={{ width: "30px", height: "32px" , marginTop: '5px' , marginLeft: '0px'}}
            />
          </Link>
        </div>
        <ul className="nav-links" id="adminnavbar">
          <li>
            <Link id="adminnavbar"to="/adminhome">Home</Link>
          </li>
          <li>
            <Link id="adminnavbar"to="/updates">Updates from Customers</Link>
          </li>
          <li>
            <Link id="adminnavbar"to="/admincheckstatus">Loan</Link>
          </li>
          <li>
            <Link id="adminnavbar" to="/admincontactus">Contact To Customer</Link>
          </li>
          
          <li>
            <Link id="adminnavbar" to="/adminreview" >
              Customers Review
            </Link>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default AdminNavbar;
